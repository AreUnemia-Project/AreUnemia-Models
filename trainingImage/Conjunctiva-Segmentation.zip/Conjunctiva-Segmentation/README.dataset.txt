# Conjunctiva-Segmentation-2 > Segmentation_2
https://universe.roboflow.com/conjunctiva-pallor-segmentation/conjunctiva-segmentation-2

Provided by a Roboflow user
License: CC BY 4.0

